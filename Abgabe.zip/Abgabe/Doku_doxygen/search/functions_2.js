var searchData=
[
  ['interpreter_0',['Interpreter',['../classihk24__v1_1_1_interpreter.html#a1963e0867ebbcbac70261ef056caa6e6',1,'ihk24_v1::Interpreter']]],
  ['isvalidnachfolger_1',['isValidNachfolger',['../classihk24__v1_1_1_kodierung.html#a66ecab96555142b7f93bc68ba57a932b',1,'ihk24_v1::Kodierung']]]
];
