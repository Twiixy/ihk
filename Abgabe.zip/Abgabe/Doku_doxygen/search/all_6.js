var searchData=
[
  ['kodierung_0',['Kodierung',['../classihk24__v1_1_1_kodierung.html',1,'ihk24_v1.Kodierung'],['../classihk24__v1_1_1_kodierung.html#a8aa845a2a4f83209518b6b71f2d6e15c',1,'ihk24_v1.Kodierung.Kodierung()']]],
  ['kommentar_1',['Kommentar',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#adfc6cb6cd25593b080976b09a6395563',1,'ihk24_v1::Puzzle::Holzpuzzel']]]
];
