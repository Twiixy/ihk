var searchData=
[
  ['issolved_0',['isSolved',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#aa61738fdb79276afcb4fa80d01ffe131',1,'ihk24_v1::Puzzle::Holzpuzzel']]]
];
