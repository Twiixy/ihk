var searchData=
[
  ['dateiname_0',['DateiName',['../classihk24__v1_1_1_interpreter.html#acfa06f6e471831e4d4d94ebc9ab8eb1c',1,'ihk24_v1::Interpreter']]],
  ['dimensionsstring_1',['DimensionsString',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#a60db31a64ae1fe7e6cccd192363dacf0',1,'ihk24_v1::Puzzle::Holzpuzzel']]]
];
