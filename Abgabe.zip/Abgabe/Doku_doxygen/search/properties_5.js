var searchData=
[
  ['kommentar_0',['Kommentar',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#adfc6cb6cd25593b080976b09a6395563',1,'ihk24_v1::Puzzle::Holzpuzzel']]]
];
