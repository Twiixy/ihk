var searchData=
[
  ['breite_0',['Breite',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#a1073e4918bd92890d2c111583a7727a8',1,'ihk24_v1::Puzzle::Holzpuzzel']]]
];
