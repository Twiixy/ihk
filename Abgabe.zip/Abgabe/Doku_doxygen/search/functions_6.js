var searchData=
[
  ['solve_0',['solve',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#acfd79a9baf2ead8d11a395e2b8cc1e3a',1,'ihk24_v1::Puzzle::Holzpuzzel']]],
  ['streifenplazieren_1',['streifenPlazieren',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#a7f619f1be4af5f75960bedabe0383dfa',1,'ihk24_v1::Puzzle::Holzpuzzel']]]
];
