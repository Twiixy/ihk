var searchData=
[
  ['pruefeholzstreifenids_0',['pruefeHolzstreifenIds',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#a6c8c93c1ecc35eabd8ea7ed5bb6c46b3',1,'ihk24_v1::Puzzle::Holzpuzzel']]],
  ['pruefevollstaendigkeit_1',['pruefeVollstaendigkeit',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#a56456877ba3c357a384514c74ce0995c',1,'ihk24_v1::Puzzle::Holzpuzzel']]]
];
