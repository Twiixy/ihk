var searchData=
[
  ['id_0',['ID',['../classihk24__v1_1_1_puzzle_1_1_holzstreifen.html#ac15f906c42e5126e376c3ff23c28c690',1,'ihk24_v1::Puzzle::Holzstreifen']]],
  ['isused_1',['IsUsed',['../classihk24__v1_1_1_puzzle_1_1_holzstreifen.html#ae1fcfa0b66505830fee5f7ea8fa96c3e',1,'ihk24_v1::Puzzle::Holzstreifen']]]
];
