var searchData=
[
  ['removestreifen_0',['removeStreifen',['../classihk24__v1_1_1_puzzle_1_1_holzpuzzel.html#a91b848d2ef7a24ef36d541d433ba46e2',1,'ihk24_v1::Puzzle::Holzpuzzel']]],
  ['rotationstests_1',['rotationsTests',['../classihk24__v1_1_1_tests_1_1_holz_streifen_tester.html#a223521cdcf0fa2f211fbfe0cd2534f71',1,'ihk24_v1::Tests::HolzStreifenTester']]],
  ['rotieren_2',['rotieren',['../classihk24__v1_1_1_puzzle_1_1_holzstreifen.html#a0b440aacee4e0e4cfac63a7f3764eae6',1,'ihk24_v1::Puzzle::Holzstreifen']]]
];
