var searchData=
[
  ['herstellername_0',['Herstellername',['../classihk24__v1_1_1_puzzle_1_1_holzspielzeug.html#a660e19ad16a979f13be0dc31536ec450',1,'ihk24_v1::Puzzle::Holzspielzeug']]]
];
