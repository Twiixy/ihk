var searchData=
[
  ['kodierung_0',['Kodierung',['../classihk24__v1_1_1_kodierung.html',1,'ihk24_v1']]]
];
