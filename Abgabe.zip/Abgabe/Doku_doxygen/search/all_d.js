var searchData=
[
  ['u_5fnachfolger_0',['u_nachfolger',['../classihk24__v1_1_1_kodierung.html#a2f28e275435e4cdf2fe582ad69478d16',1,'ihk24_v1::Kodierung']]]
];
