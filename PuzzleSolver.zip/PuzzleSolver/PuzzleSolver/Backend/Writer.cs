using PuzzleSolver.Interfaces;

namespace PuzzleSolver.Backend;

public class Writer : IWriter
{
    public void WriteData(string outputFile, Stack<PuzzlePiece[]> data, List<string> comments)
    {
        throw new NotImplementedException();
    }
}