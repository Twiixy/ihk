namespace PuzzleSolver.Config;

public class Arguments
{
    public string InputFile { get; set; }
}